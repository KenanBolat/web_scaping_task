//tealium universal tag - utag.396 ut4.0.201506091403, Copyright 2015 Tealium.com Inc. All Rights Reserved.
try{(function(id,loader,u){try{u=utag.o[loader].sender[id]={}}catch(e){u=utag.sender[id]};u.ev={'view':1};u.t='@@',u.i=[],u.p=["//analytics.twitter.com/i/adsct?txn_id=l48vn&p_id=Twitter","//t.co/i/adsct?txn_id=l48vn&p_id=Twitter","","","","","",""];u.cachebust="enabled";u.cachevar=""||"_rnd";u.map={};u.extend=[];u.send=function(a,b,c,d,e,f){if(u.ev[a]){for(c=0;c<u.p.length;c++){if(u.p[c]!=""){var x=u.rp(u.p[c],b);if(x!=""){if(u.cachebust=="enabled"&&x.indexOf("_rnd")<0){x+="&"+u.cachevar+"="+Math.random();}
var img=new Image();img.src=x;u.i.push(img);}}}}}
u.rp=function(a,b){if(typeof a!="undefined"&&a.indexOf(u.t)>0){a=a.replace(/@@([^@]+)@@/g,function(m,d){if(b[d]){return encodeURIComponent(b[d]);}else{return'';}});}
return a;}
try{utag.o[loader].loader.LOAD(id)}catch(e){utag.loader.LOAD(id)}})('396','booking.com.main');}catch(error){utag.DB(error);}
